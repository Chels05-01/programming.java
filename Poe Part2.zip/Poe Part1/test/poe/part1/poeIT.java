
package poe.part1;

import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

public class poeIT {

    // Test 1: Test message hash creation
    @Test
    public void testCreateMessageHash() {

        Message msg = new Message(
                "1234567890",
                1,
                "+27821234567",
                "Hello there"
        );

        assertEquals(
                "12:1:HELLOTHERE",
                msg.createMessageHash()
        );
    }

    // Test 2: Test a valid recipient cellphone number
    @Test
    public void testValidRecipientCell() {

        Message msg = new Message(
                "1234567890",
                1,
                "+27821234567",
                "Hello"
        );

        assertTrue(msg.checkRecipientCell());
    }

    // Test 3: Test an invalid recipient cellphone number
    @Test
    public void testInvalidRecipientCell() {

        Message msg = new Message(
                "1234567890",
                1,
                "0821234567",
                "Hello"
        );

        assertFalse(msg.checkRecipientCell());
    }

    // Test 4: Test message hash with a different message number
    @Test
    public void testMessageHashWithDifferentNumber() {

        Message msg = new Message(
                "9876543210",
                5,
                "+27821234567",
                "Quick Chat"
        );

        assertEquals(
                "98:5:QUICKCHAT",
                msg.createMessageHash()
        );
    }

    // Test 5: Test that a sent message increases the total
    @Test
    public void testSendMessage() {

        int previousTotal = Message.returnTotalMessages();

        String simulatedInput =
                "+27821234567\n"
                + "Hello from JUnit\n"
                + "1\n";

        Scanner input = new Scanner(simulatedInput);

        int processed = Message.sendMessages(input, 1);

        assertEquals(1, processed);

        assertEquals(
                previousTotal + 1,
                Message.returnTotalMessages()
        );

        input.close();
    }

    // Test 6: Test an empty message hash
    @Test
    public void testEmptyMessageHash() {

        Message msg = new Message(
                "1234567890",
                2,
                "+27821234567",
                ""
        );

        assertEquals(
                "12:2:",
                msg.createMessageHash()
        );
    }
}
