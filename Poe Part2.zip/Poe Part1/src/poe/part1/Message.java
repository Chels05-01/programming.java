
package poe.part1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Message {

    // =========================
    // MESSAGE VARIABLES
    // =========================

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;

    private static final Random random = new Random();

    private static final ArrayList<Message> sentMessages =
            new ArrayList<>();

    private static final ArrayList<Message> disregardedMessages =
            new ArrayList<>();

    private static final ArrayList<Message> storedMessages =
            new ArrayList<>();

    private static int totalMessages = 0;
    private static int messageCounter = 0;

    private static final String JSON_FILE = "stored_messages.json";

    // =========================
    // CONSTRUCTOR
    // =========================

    public Message(
            String messageID,
            int messageNumber,
            String recipient,
            String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
        this.messageStatus = "Pending";
    }

    // =========================
    // LINK TO MAIN CLASS
    // =========================

    // Called from poe.java after successful login
    public static void startQuickChat(
            Scanner input, Login user) {

        if (user == null || !user.isLoggedIn()) {

            System.out.println(
                "Login unsuccessful. Access denied."
            );
            return;
        }

        System.out.println("\n================================");
        System.out.println("       WELCOME TO QUICKCHAT");
        System.out.println("================================");

        int numberOfMessages;

        // Ask the user how many messages to process
        while (true) {

            System.out.print(
                "How many messages would you like to enter? "
            );

            if (input.hasNextInt()) {

                numberOfMessages = input.nextInt();
                input.nextLine();

                if (numberOfMessages >= 0) {
                    break;
                }
            } else {
                input.nextLine();
            }

            System.out.println(
                "Please enter a valid number (0 or greater)."
            );
        }

        int remainingMessages = numberOfMessages;
        boolean running = true;

        // QuickChat menu
        while (running) {

            System.out.println("\n========== QUICKCHAT MENU ==========");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.print("Choose an option: ");

            String option = input.nextLine();

            switch (option) {

                case "1":

                    if (!user.isLoggedIn()) {
                        System.out.println(
                            "Please log in first."
                        );
                        return;
                    }

                    if (remainingMessages > 0) {

                        int processed = sendMessages(
                            input, remainingMessages
                        );

                        remainingMessages -= processed;

                    } else {

                        System.out.println(
                            "You have reached your message limit."
                        );
                    }

                    break;

                case "2":

                    displayRecentlySentMessages();
                    break;

                case "3":

                    running = false;

                    System.out.println(
                        "Thank you for using QuickChat."
                    );
                    break;

                default:

                    System.out.println(
                        "Invalid option. Please select 1, 2 or 3."
                    );
            }
        }

        System.out.println(
            "\nTotal messages successfully sent: "
            + returnTotalMessages()
        );
    }

    // =========================
    // GENERATE MESSAGE ID
    // =========================

    // Generate a unique ten-digit message ID
    private static String generateMessageID() {

        String id;

        do {

            long number = 1_000_000_000L
                    + (long) (random.nextDouble()
                    * 9_000_000_000L);

            id = String.valueOf(number);

        } while (messageIDExists(id));

        return id;
    }

    // Check whether the ID already exists
    private static boolean messageIDExists(String id) {

        for (Message m : sentMessages) {
            if (m.messageID.equals(id)) {
                return true;
            }
        }

        for (Message m : storedMessages) {
            if (m.messageID.equals(id)) {
                return true;
            }
        }

        for (Message m : disregardedMessages) {
            if (m.messageID.equals(id)) {
                return true;
            }
        }

        return false;
    }

    // =========================
    // VALIDATE RECIPIENT
    // =========================

    // International format, for example +27821234567
    public boolean checkRecipientCell() {

        return recipient != null
                && recipient.matches("\\+[1-9]\\d{7,14}");
    }

    // =========================
    // CREATE MESSAGE HASH
    // =========================

    public String createMessageHash() {

        String trimmedMessage = message.trim();
        String firstWord = "";
        String lastWord = "";

        if (!trimmedMessage.isEmpty()) {

            String[] words = trimmedMessage.split("\\s+");

            firstWord = words[0];
            lastWord = words[words.length - 1];
        }

        return (
            messageID.substring(0, 2) + ":"
            + messageNumber + ":"
            + firstWord + lastWord
        ).toUpperCase();
    }

    // =========================
    // SEND MESSAGES
    // =========================

    public static int sendMessages(
            Scanner input, int numberOfMessages) {

        int processed = 0;

        for (int i = 0; i < numberOfMessages; i++) {

            System.out.println(
                "\n========== MESSAGE "
                + (messageCounter + 1) + " =========="
            );

            String id = generateMessageID();

            System.out.println(
                "Message ID generated: " + id
            );

            // Capture and validate recipient
            String recipient;

            while (true) {

                System.out.print(
                    "Enter recipient cellphone number "
                    + "with international code: "
                );

                recipient = input.nextLine();

                Message temporary = new Message(
                    id,
                    messageCounter + 1,
                    recipient,
                    ""
                );

                if (temporary.checkRecipientCell()) {

                    System.out.println(
                        "Cellphone number successfully captured."
                    );
                    break;

                } else {

                    System.out.println(
                        "Invalid number. Use international format, "
                        + "for example +27821234567."
                    );
                }
            }

            // Capture message: fewer than 250 characters
            String messageText;

            while (true) {

                System.out.print("Enter your message: ");
                messageText = input.nextLine();

                if (messageText.length() < 250) {
                    break;
                }

                System.out.println(
                    "Please enter a message of less than "
                    + "250 characters."
                );
            }

            messageCounter++;

            Message newMessage = new Message(
                id,
                messageCounter,
                recipient,
                messageText
            );

            System.out.println(
                "Message Hash: " + newMessage.messageHash
            );

            boolean completed = false;

            while (!completed) {

                System.out.println("\nChoose an option:");
                System.out.println("1. Send Message");
                System.out.println("2. Disregard Message");
                System.out.println("3. Store Message to send later");
                System.out.print("Enter your choice: ");

                String choice = input.nextLine();

                switch (choice) {

                    case "1":

                        newMessage.messageStatus = "Sent";
                        sentMessages.add(newMessage);
                        totalMessages++;

                        System.out.println(
                            "Message successfully sent."
                        );

                        displayMessage(newMessage);

                        completed = true;
                        break;

                    case "2":

                        System.out.println(
                            "Press 0 to delete the message."
                        );

                        String deleteChoice = input.nextLine();

                        if (deleteChoice.equals("0")) {

                            newMessage.messageStatus = "Disregarded";
                            disregardedMessages.add(newMessage);

                            System.out.println(
                                "Message deleted."
                            );

                            completed = true;

                        } else {

                            System.out.println(
                                "Invalid choice. Please try again."
                            );
                        }

                        break;

                    case "3":

                        newMessage.messageStatus = "Stored";
                        storedMessages.add(newMessage);

                        saveStoredMessagesToJSON();

                        System.out.println(
                            "Message successfully stored."
                        );

                        completed = true;
                        break;

                    default:

                        System.out.println(
                            "Invalid option. Please select 1, 2 or 3."
                        );
                }
            }

            processed++;
        }

        return processed;
    }

    // =========================
    // DISPLAY MESSAGE DETAILS
    // =========================

    private static void displayMessage(Message m) {

        System.out.println(
            "\n========== MESSAGE DETAILS =========="
        );

        System.out.println("Message ID: " + m.messageID);
        System.out.println("Message Hash: " + m.messageHash);
        System.out.println("Recipient: " + m.recipient);
        System.out.println("Message: " + m.message);
        System.out.println("Status: " + m.messageStatus);

        System.out.println(
            "====================================="
        );
    }

    // =========================
    // DISPLAY RECENTLY SENT MESSAGES
    // =========================

    public static void displayRecentlySentMessages() {

        if (sentMessages.isEmpty()) {

            System.out.println(
                "No messages have been sent yet."
            );
            return;
        }

        System.out.println("\n========== SENT MESSAGES ==========");

        for (Message m : sentMessages) {
            displayMessage(m);
        }
    }

    // =========================
    // SAVE STORED MESSAGES TO JSON
    // =========================

    private static void saveStoredMessagesToJSON() {

        try (FileWriter writer = new FileWriter(JSON_FILE)) {

            writer.write("[\n");

            for (int i = 0; i < storedMessages.size(); i++) {

                Message m = storedMessages.get(i);

                writer.write("  {\n");

                writer.write(
                    "    \"messageID\": \""
                    + escapeJSON(m.messageID) + "\",\n"
                );

                writer.write(
                    "    \"messageNumber\": "
                    + m.messageNumber + ",\n"
                );

                writer.write(
                    "    \"recipient\": \""
                    + escapeJSON(m.recipient) + "\",\n"
                );

                writer.write(
                    "    \"message\": \""
                    + escapeJSON(m.message) + "\",\n"
                );

                writer.write(
                    "    \"messageHash\": \""
                    + escapeJSON(m.messageHash) + "\",\n"
                );

                writer.write(
                    "    \"messageStatus\": \""
                    + escapeJSON(m.messageStatus) + "\"\n"
                );

                writer.write("  }");

                if (i < storedMessages.size() - 1) {
                    writer.write(",");
                }

                writer.write("\n");
            }

            writer.write("]\n");

            System.out.println(
                "Messages saved to " + JSON_FILE
            );

        } catch (IOException e) {

            System.out.println(
                "Error saving JSON file: " + e.getMessage()
            );
        }
    }

    // =========================
    // ESCAPE JSON CHARACTERS
    // =========================

    private static String escapeJSON(String text) {

        return text.replace("\\", "\\\\")
                   .replace("\"", "\\\"")
                   .replace("\n", "\\n")
                   .replace("\r", "\\r")
                   .replace("\t", "\\t");
    }

    // =========================
    // RETURN TOTAL SENT MESSAGES
    // =========================

    public static int returnTotalMessages() {

        return totalMessages;
    }
}


