
package poe.part1;

public class Login {

    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    private String storedUsername;
    private String storedPassword;

    private boolean loggedIn = false;

    // Constructor
    public Login(String fname, String lname) {
        this.firstName = fname;
        this.lastName = lname;
    }

    // Check username
    public boolean checkUserName(String username) {

        if (username == null || username.isEmpty()) {
            return false;
        }

        if (!username.contains("_")) {
            return false;
        }

        if (username.length() > 5) {
            return false;
        }

        boolean hasAlphabet = false;

        for (int i = 0; i < username.length(); i++) {
            if (Character.isLetter(username.charAt(i))) {
                hasAlphabet = true;
                break;
            }
        }

        return hasAlphabet;
    }

    // Check password complexity
    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {

            char current = password.charAt(i);

            if (Character.isUpperCase(current)) {
                hasCapital = true;
            }

            if (Character.isDigit(current)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(current)) {
                hasSpecial = true;
            }
        }

        return hasCapital && hasNumber && hasSpecial;
    }

    // Check cellphone number
    public boolean checkCellPhoneNumber(String number) {

        if (number == null) {
            return false;
        }

        if (!number.startsWith("+27") || number.length() != 12) {
            return false;
        }

        for (int i = 3; i < number.length(); i++) {
            if (!Character.isDigit(number.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    // Register user
    public String registerUser(
            String username,
            String password,
            String cellNumber,
            String fName,
            String lName) {

        loggedIn = false;

        if (!checkUserName(username)) {
            return "Username is not correctly formatted.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted.";
        }

        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cellphone number is incorrectly formatted.";
        }

        this.firstName = fName;
        this.lastName = lName;
        this.cellPhoneNumber = cellNumber;
        this.storedUsername = username;
        this.storedPassword = password;

        return "Registration successful.";
    }

    // Authenticate login
    public boolean loginUser(String username, String password) {

        loggedIn = storedUsername != null
                && storedPassword != null
                && username != null
                && password != null
                && username.equals(storedUsername)
                && password.equals(storedPassword);

        return loggedIn;
    }

    // Return login message
    public String returnLoginStatus(
            String username, String password) {

        if (loginUser(username, password)) {
            return "Welcome " + firstName + " " + lastName
                    + ", it is great to see you again.";
        }

        return "Username or password incorrect, please try again.";
    }

    // Check whether user is logged in
    public boolean isLoggedIn() {
        return loggedIn;
    }

    // Log out user
    public void logoutUser() {
        loggedIn = false;
    }

    // Getters
    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }
}
