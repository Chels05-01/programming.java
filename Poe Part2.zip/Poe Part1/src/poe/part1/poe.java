
package poe.part1;

import java.util.Scanner;

public class poe {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String name;
        String surname;
        String username;
        String cellphone;
        String password;

        // =========================
        // USER REGISTRATION
        // =========================

        System.out.println("========== REGISTRATION ==========");

        System.out.print("Enter user name: ");
        name = input.nextLine();

        System.out.print("Enter user surname: ");
        surname = input.nextLine();

        // Create Login object
        Login user = new Login(name, surname);

        // =========================
        // USERNAME VALIDATION
        // =========================

        while (true) {

            System.out.print("Enter username: ");
            username = input.nextLine();

            if (user.checkUserName(username)) {

                System.out.println(
                    "Username successfully captured."
                );
                break;

            } else {

                System.out.println("Username is unsuccessful.");
                System.out.println(
                    "Username must contain an underscore (_)."
                );
                System.out.println(
                    "Username must be no more than 5 characters long."
                );
                System.out.println(
                    "Username must contain at least one alphabetic character."
                );
                System.out.println("Example: ab_12");
            }
        }

        // =========================
        // PASSWORD VALIDATION
        // =========================

        while (true) {

            System.out.print("Enter user password: ");
            password = input.nextLine();

            if (user.checkPasswordComplexity(password)) {

                System.out.println(
                    "Password successfully captured."
                );
                break;

            } else {

                System.out.println("Password is unsuccessful.");
                System.out.println(
                    "Password must contain at least 8 characters."
                );
                System.out.println(
                    "Password must contain at least 1 number."
                );
                System.out.println(
                    "Password must contain at least 1 special character."
                );
                System.out.println(
                    "Password must contain at least 1 capital letter."
                );
            }
        }

        // =========================
        // CELLPHONE VALIDATION
        // =========================

        while (true) {

            System.out.print("Enter cellphone number: ");
            cellphone = input.nextLine();

            if (user.checkCellPhoneNumber(cellphone)) {

                System.out.println(
                    "Cellphone number successfully captured."
                );
                break;

            } else {

                System.out.println(
                    "Cellphone number is unsuccessful."
                );
                System.out.println(
                    "Number must start with +27 and contain "
                    + "9 digits after the country code."
                );
                System.out.println("Example: +27821234567");
            }
        }

        // =========================
        // REGISTER USER
        // =========================

        String registrationMessage = user.registerUser(
            username,
            password,
            cellphone,
            name,
            surname
        );

        System.out.println();
        System.out.println(registrationMessage);

        System.out.println(
            "\nWelcome " + name + " " + surname
        );
        System.out.println("Username: " + username);
        System.out.println("Cellphone: " + cellphone);

        // =========================
        // USER LOGIN
        // =========================

        System.out.println("\n========== LOGIN ==========");

        boolean loginSuccessful = false;

        while (!loginSuccessful) {

            System.out.print("Enter your username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter your password: ");
            String loginPassword = input.nextLine();

            loginSuccessful = user.loginUser(
                loginUsername,
                loginPassword
            );

            if (loginSuccessful) {

                System.out.println(
                    user.returnLoginStatus(
                        loginUsername,
                        loginPassword
                    )
                );

                System.out.println(
                    "Login successful!"
                );

            } else {

                System.out.println(
                    "Username or password incorrect. Please try again."
                );
            }
        }

        // =========================
        // LINK TO QUICKCHAT
        // =========================

        // Pass the Scanner and logged-in user to Message.java
        Message.startQuickChat(input, user);

        // Close Scanner after QuickChat ends
        input.close();
    }
}


