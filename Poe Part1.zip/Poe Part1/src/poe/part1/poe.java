package poe.part1;

import java.util.Scanner;

public class poe {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String name;
        String surname;
        String username;
        String cellphone;
        String password;

        // =========================
        // GET FIRST NAME
        // =========================
        System.out.println("Enter user name:");
        name = input.nextLine();

        // =========================
        // GET SURNAME
        // =========================
        System.out.println("Enter user surname:");
        surname = input.nextLine();

        // Create Login object
        Login user = new Login(name, surname);

        // =========================
        // USERNAME REGISTRATION
        // =========================
        while (true) {

            System.out.println("Enter username:");
            username = input.nextLine();

            if (user.checkUserName(username)) {

                System.out.println("Username successfully captured.");
                break;

            } else {

                System.out.println("Username is unsuccessful.");
                System.out.println(
                    "Username must contain an underscore (_)."
                );
                System.out.println(
                    "Username must be no more than 5 characters long."
                );
                System.out.println(
                    "Username must contain at least one alphabetic character."
                );
                System.out.println(
                    "Example: ab_12"
                );
            }
        }

        // =========================
        // PASSWORD REGISTRATION
        // =========================
        while (true) {

            System.out.println("Enter user password:");
            password = input.nextLine();

            if (user.checkPasswordComplexity(password)) {

                System.out.println("Password successfully captured.");
                break;

            } else {

                System.out.println("Password is unsuccessful.");
                System.out.println(
                    "Password must contain at least 8 characters."
                );
                System.out.println(
                    "Password must contain at least 1 number."
                );
                System.out.println(
                    "Password must contain at least 1 special character."
                );
                System.out.println(
                    "Password must contain at least 1 capital letter."
                );
            }
        }

        // =========================
        // CELLPHONE REGISTRATION
        // =========================
        while (true) {

            System.out.println("Enter cellphone number:");
            cellphone = input.nextLine();

            if (user.checkCellPhoneNumber(cellphone)) {

                System.out.println(
                    "Cellphone number successfully captured."
                );
                break;

            } else {

                System.out.println(
                    "Cellphone number is unsuccessful."
                );
                System.out.println(
                    "Cellphone number must start with +27 "
                    + "and be followed by 9 numbers."
                );
                System.out.println(
                    "Example: +27821234567"
                );
            }
        }

        // =========================
        // REGISTER USER
        // =========================
        String registrationMessage = user.registerUser(
            username,
            password,
            cellphone,
            name,
            surname
        );

        System.out.println(registrationMessage);

        System.out.println();
        System.out.println("You have registered successfully.");
        System.out.println(
            "Welcome " + name + " " + surname
            + " aka " + username
        );
        System.out.println("Cellphone: " + cellphone);

        // =========================
        // LOGIN
        // =========================
        System.out.println();
        System.out.println("========== LOGIN ==========");

        String loginUsername;
        String loginPassword;

        while (true) {

            System.out.println("Enter your username:");
            loginUsername = input.nextLine();

            System.out.println("Enter your password:");
            loginPassword = input.nextLine();

            if (user.loginUser(loginUsername, loginPassword)) {

                System.out.println(
                    user.returnLoginStatus(
                        loginUsername,
                        loginPassword
                    )
                );

                break;

            } else {

                System.out.println(
                    "Username or password incorrect, please try again."
                );
                System.out.println();
            }
        }

        input.close();
    }
}