package poe.part1;

public class Login {

    // User information
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;

    // Login information
    private String storedUsername;
    private String storedPassword;

    // CONSTRUCTOR
  
    public Login(String fname, String lname) {

        this.firstName = fname;
        this.lastName = lname;
    }

    // CHECK USERNAME

    public boolean checkUserName(String username) {

        // Check if username is empty
        if (username == null || username.isEmpty()) {
            return false;
        }

        // Username must contain an underscore
        if (!username.contains("_")) {
            return false;
        }

        // Username must be no more than 5 characters
        if (username.length() > 5) {
            return false;
        }

        // Username must contain at least one alphabetic character
        boolean hasAlphabet = false;

        for (int i = 0; i < username.length(); i++) {

            char current = username.charAt(i);

            if (Character.isLetter(current)) {

                hasAlphabet = true;
                break;
            }
        }

        return hasAlphabet;
    }

    // ==========================================
    // CHECK PASSWORD
    // ==========================================
    public boolean checkPasswordComplexity(String password) {

        // Password must contain at least 8 characters
        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        // Check each character in the password
        for (int i = 0; i < password.length(); i++) {

            char current = password.charAt(i);

            // Check for capital letter
            if (Character.isUpperCase(current)) {
                hasCapital = true;
            }

            // Check for number
            if (Character.isDigit(current)) {
                hasNumber = true;
            }

            // Check for special character
            if (!Character.isLetterOrDigit(current)) {
                hasSpecial = true;
            }
        }

        // Password needs:
        // At least 8 characters
        // At least 1 capital letter
        // At least 1 number
        // At least 1 special character

        return hasCapital && hasNumber && hasSpecial;
    }

    // ==========================================
    // CHECK CELLPHONE NUMBER
    // ==========================================
    public boolean checkCellPhoneNumber(String number) {

        if (number == null) {
            return false;
        }

        // Must start with +27
        if (!number.startsWith("+27")) {
            return false;
        }

        // +27 + 9 digits = 12 characters
        if (number.length() != 12) {
            return false;
        }

        // Check that all characters after +27 are digits
        for (int i = 3; i < number.length(); i++) {

            if (!Character.isDigit(number.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    // ==========================================
    // REGISTER USER
    // ==========================================
    public String registerUser(
            String username,
            String password,
            String cellNumber,
            String fName,
            String lName) {

        // Store names
        this.firstName = fName;
        this.lastName = lName;

        // Validate username
        if (!checkUserName(username)) {

            return "Username is not correctly formatted.";
        }

        // Validate password
        if (!checkPasswordComplexity(password)) {

            return "Password is not correctly formatted.";
        }

        // Validate cellphone
        if (!checkCellPhoneNumber(cellNumber)) {

            return "Cellphone number is incorrectly formatted.";
        }

        // Store registration details
        this.cellPhoneNumber = cellNumber;
        this.storedUsername = username;
        this.storedPassword = password;

        return "Registration successful.";
    }

    // ==========================================
    // LOGIN USER
    // ==========================================
    public boolean loginUser(String username, String password) {

        if (storedUsername == null || storedPassword == null) {
            return false;
        }

        return username.equals(storedUsername)
                && password.equals(storedPassword);
    }

    // ==========================================
    // RETURN LOGIN STATUS
    // ==========================================
    public String returnLoginStatus(
            String username,
            String password) {

        if (loginUser(username, password)) {

            return "Welcome "
                    + firstName
                    + " "
                    + lastName
                    + " it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}