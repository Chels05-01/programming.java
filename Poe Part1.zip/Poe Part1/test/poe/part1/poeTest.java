package poe.part1;

import org.junit.Test;
import static org.junit.Assert.*;

public class poeTest {

    // ==========================================
    // USERNAME TESTS
    // ==========================================

    @Test
    public void testValidUsername() {
        Login user = new Login("Chelsea", "Diale");

        assertTrue(user.checkUserName("ab_12"));
    }

    @Test
    public void testUsernameMustContainUnderscore() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkUserName("abc12"));
    }

    @Test
    public void testUsernameMaximumFiveCharacters() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkUserName("abcdef"));
    }

    @Test
    public void testUsernameMustContainAlphabet() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkUserName("123_4"));
    }

    @Test
    public void testEmptyUsername() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkUserName(""));
    }


    // ==========================================
    // PASSWORD TESTS
    // ==========================================

    @Test
    public void testValidPassword() {
        Login user = new Login("Chelsea", "Diale");

        assertTrue(user.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testPasswordMustHaveEightCharacters() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkPasswordComplexity("Pa1!"));
    }

    @Test
    public void testPasswordMustHaveNumber() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkPasswordComplexity("Password!"));
    }

    @Test
    public void testPasswordMustHaveSpecialCharacter() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkPasswordComplexity("Password1"));
    }

    @Test
    public void testPasswordMustHaveCapitalLetter() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkPasswordComplexity("password1!"));
    }


    // ==========================================
    // CELLPHONE NUMBER TESTS
    // ==========================================

    @Test
    public void testValidCellPhoneNumber() {
        Login user = new Login("Chelsea", "Diale");

        assertTrue(user.checkCellPhoneNumber("+27821234567"));
    }

    @Test
    public void testCellPhoneMustStartWith27() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkCellPhoneNumber("0821234567"));
    }

    @Test
    public void testCellPhoneNumberMustHaveCorrectLength() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkCellPhoneNumber("+2782123456"));
    }

    @Test
    public void testCellPhoneMustContainNumbersOnlyAfter27() {
        Login user = new Login("Chelsea", "Diale");

        assertFalse(user.checkCellPhoneNumber("+27821ABC567"));
    }


    // ==========================================
    // REGISTRATION TESTS
    // ==========================================

    @Test
    public void testSuccessfulRegistration() {
        Login user = new Login("Chelsea", "Diale");

        String result = user.registerUser(
                "ab_12",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        assertEquals("Registration successful.", result);
    }

    @Test
    public void testRegistrationWithInvalidUsername() {
        Login user = new Login("Chelsea", "Diale");

        String result = user.registerUser(
                "abcdef",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        assertEquals(
                "Username is not correctly formatted.",
                result
        );
    }

    @Test
    public void testRegistrationWithInvalidPassword() {
        Login user = new Login("Chelsea", "Diale");

        String result = user.registerUser(
                "ab_12",
                "password",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        assertEquals(
                "Password is not correctly formatted.",
                result
        );
    }

    @Test
    public void testRegistrationWithInvalidCellPhone() {
        Login user = new Login("Chelsea", "Diale");

        String result = user.registerUser(
                "ab_12",
                "Password1!",
                "0821234567",
                "Chelsea",
                "Diale"
        );

        assertEquals(
                "Cellphone number is incorrectly formatted.",
                result
        );
    }


    // ==========================================
    // LOGIN TESTS
    // ==========================================

    @Test
    public void testSuccessfulLogin() {

        Login user = new Login("Chelsea", "Diale");

        user.registerUser(
                "ab_12",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        assertTrue(
                user.loginUser("ab_12", "Password1!")
        );
    }

    @Test
    public void testLoginWithIncorrectUsername() {

        Login user = new Login("Chelsea", "Diale");

        user.registerUser(
                "ab_12",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        assertFalse(
                user.loginUser("wrong", "Password1!")
        );
    }

    @Test
    public void testLoginWithIncorrectPassword() {

        Login user = new Login("Chelsea", "Diale");

        user.registerUser(
                "ab_12",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        assertFalse(
                user.loginUser("ab_12", "Wrong123!")
        );
    }


    // ==========================================
    // LOGIN STATUS TEST
    // ==========================================

    @Test
    public void testReturnLoginStatus() {

        Login user = new Login("Chelsea", "Diale");

        user.registerUser(
                "ab_12",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        String result = user.returnLoginStatus(
                "ab_12",
                "Password1!"
        );

        assertEquals(
                "Welcome Chelsea Diale it is great to see you again.",
                result
        );
    }

    @Test
    public void testReturnLoginStatusIncorrectDetails() {

        Login user = new Login("Chelsea", "Diale");

        user.registerUser(
                "ab_12",
                "Password1!",
                "+27821234567",
                "Chelsea",
                "Diale"
        );

        String result = user.returnLoginStatus(
                "wrong",
                "wrong123!"
        );

        assertEquals(
                "Username or password incorrect, please try again.",
                result
        );
    }
}